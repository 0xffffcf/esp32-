#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include "../lib/ArduinoJson/ArduinoJson.h"
#include <Wire.h>  // Only needed for Arduino 1.6.5 and earlier
#include "SSD1306Wire.h" // legacy include: `#include "SSD1306.h"`

// Initialize the OLED display using Wire library
SSD1306Wire  display(0x3c, SDA, SCL);


void setup() {
  Serial.begin(115200);

  // Initialising the UI will init the display too.
  display.init();

  // This will make sure that multiple instances of a display driver
  // running on different ports will work together transparently
  display.setI2cAutoInit(true);
  display.flipScreenVertically();
  display.setFont(ArialMT_Plain_16);
  display.setTextAlignment(TEXT_ALIGN_LEFT);

  display.clear();
  WiFi.scanNetworks(); 
   int numberOfNetworks= WiFi.scanNetworks();
   int i;
  for (i=0;i<numberOfNetworks;i+=4){
  display.drawString(0, 0, WiFi.SSID(i));
  display.display();
  delay(1000);
  display.drawString(0, 15, WiFi.SSID(i+1));
  display.display();
  delay(1000);
  display.drawString(0, 30, WiFi.SSID(i+2));
  display.display();
  delay(1000);
  display.drawString(0, 45, WiFi.SSID(i+3));
  display.display();
  delay(1000);
  display.clear();
  }
  
}

void loop() {

}
